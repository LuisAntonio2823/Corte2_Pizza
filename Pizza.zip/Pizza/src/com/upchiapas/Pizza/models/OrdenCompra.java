package com.upchiapas.Pizza.models;

public class OrdenCompra {
	private int id;
	private String nombrePedido;
	private String tipoPizza;
	
	public OrdenCompra() {
		nombrePedido = "";
		id = 0;
		tipoPizza = "";
	}

	public OrdenCompra(String np, int id2, String tp) {
		nombrePedido = np;
		id = id2;
		tipoPizza = tp;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombrePedido() {
		return nombrePedido;
	}

	public void setNombrePedido(String nombrePedido) {
		this.nombrePedido = nombrePedido;
	}

	public String getTipoPizza() {
		return tipoPizza;
	}

	public void setTipoPizza(String tipoPizza) {
		this.tipoPizza = tipoPizza;
	}

}
